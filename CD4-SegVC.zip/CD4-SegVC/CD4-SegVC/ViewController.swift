//
//  ViewController.swift
//  CD4-SegVC
//
//  Created by Chen, Kunyu on 7/30/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var selectLabel: UILabel!
    @IBOutlet weak var segCtrl: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        segCtrl.selectedSegmentIndex = 2
        selectLabel.text = "3 is selected"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func segAction(_ sender: Any) {
        switch segCtrl.selectedSegmentIndex {
        case 0:
            selectLabel.text = "1 is selected"
            performSegue(withIdentifier: "VC1", sender: self)
        case 1:
            selectLabel.text = "2 is selected"
            performSegue(withIdentifier: "VC2", sender: self)
        case 2:
            selectLabel.text = "3 is selected"
        case 3:
            selectLabel.text = "4 is selected"
            self.performSegue(withIdentifier: "pop", sender: self)
        default:
            selectLabel.text = "Error"
        }
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none
    }
}

