//
//  ViewController.swift
//  StackViewDemo
//
//  Created by Chen, Kunyu on 8/9/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    
    let imageCount = 3
    var current = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        showImage(index: 0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showImage(index: Int) {
        label.text = "Album \(index)"
        imageView.image = UIImage(named: "image\(index)")
    }
    
    
    @IBAction func previousButton(_ sender: Any) {
        if current == 0 {
            current = imageCount - 1
        } else {
            current -= 1
        }
        showImage(index: current)
    }
    
    @IBAction func resetButton(_ sender: Any) {
        showImage(index: 0)
        current = 0
    }
    
    @IBAction func nextButton(_ sender: Any) {
        current = (current + 1) % imageCount
        showImage(index: current)
    }
    
}

