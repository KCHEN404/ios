//
//  ViewController.swift
//  ChenKunyu-HW8
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/7/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController, UNUserNotificationCenterDelegate {
    
    var clickCount = 0
    
    @IBOutlet weak var buttonOutlet: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        UNUserNotificationCenter.current().delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func buttonPressed(_ sender: Any) {
        if (buttonOutlet.currentBackgroundImage?.isEqual(UIImage(named: "utower")))! {
            self.buttonOutlet.alpha = 1.0
            UIView.animate(withDuration: 1.0,
                           delay: 0.0,
                           options: .curveEaseOut,
                           animations: {
                            self.buttonOutlet.alpha = 0.0
            }, completion: { finished in
                self.buttonOutlet.setBackgroundImage(#imageLiteral(resourceName: "ut"), for: UIControlState.normal)
                self.buttonOutlet.alpha = 0.0
                UIView.animate(withDuration: 1.0,
                               delay: 0.0,
                               options: .curveEaseIn,
                               animations: {
                                self.buttonOutlet.alpha = 1.0
                })
            })
            
        } else if (buttonOutlet.currentBackgroundImage?.isEqual(UIImage(named: "ut")))! {
            self.buttonOutlet.alpha = 1.0
            UIView.animate(withDuration: 1.0,
                           delay: 0.0,
                           options: .curveEaseOut,
                           animations: {
                            self.buttonOutlet.alpha = 0.0
            }, completion: { finished in
                self.buttonOutlet.setBackgroundImage(#imageLiteral(resourceName: "utower"), for: UIControlState.normal)
                self.buttonOutlet.alpha = 0.0
                UIView.animate(withDuration: 1.0,
                               delay: 0.0,
                               options: .curveEaseIn,
                               animations: {
                                self.buttonOutlet.alpha = 1.0
                })
            })
        }
        clickCount += 1
        print(clickCount)
        
        // create notification using code from Class Demo 10
        if clickCount == 4 {
            let notification = UNMutableNotificationContent()
            notification.title = "Click Count"
            notification.subtitle = "UT Images"
            notification.body = "You have clicked 4 times"
            
            let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: 8.0, repeats: false)
            let request = UNNotificationRequest(identifier: "notification1", content: notification, trigger: notificationTrigger)
            UNUserNotificationCenter.current().add(request) { (error) in
                print("Request error: ", error as Any)
            }
            print("Submitted")
        }
    }
    
    //  ADDED:  required method that presents the notification in the app.  While the app is currently
    //  open on the device screen, the notification will appear at the top.
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification:UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler ([.alert, .sound])
    }

    //  ADDED:  required method that indicates what actions, if any, you want to associate with your
    //  notification.

    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {

        // I chose to do nothing here.

    }
    
}

