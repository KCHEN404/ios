//
//  ViewController.swift
//  CD3-Alerts
//
//  Created by Chen, Kunyu on 7/30/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    let choices = [
        "Simple UIAlertViewController",
        "UIAlertViewController with Text Field",
        "UIAlertViewController with Multiple Buttons",
        "Standard UIActionSheet"
    ]

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return choices.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath:
        IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier:
            "textCell", for: indexPath as IndexPath)
        let row = indexPath.row
        cell.textLabel?.text = choices[row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rowValue = choices[indexPath.row]
        switch rowValue {
        case "Simple UIAlertViewController":
            let controller = UIAlertController(title: "Alert Controller", message: rowValue, preferredStyle: .alert)
            
            controller.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            controller.addAction(UIAlertAction(title: "OK", style: .default))
            present(controller, animated: true, completion: nil)
            
        case "UIAlertViewController with Text Field":
            let controller = UIAlertController(title: "Alert Controller", message: rowValue, preferredStyle: .alert)
            
            controller.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            controller.addTextField(configurationHandler: {(textField:UITextField!) in textField.placeholder = "Enter Something"})
            controller.addAction(UIAlertAction(title: "OK", style: .default,
                handler: {(paramAction:UIAlertAction!) in
                    if let textField = controller.textFields {
                    let theTextField = textField as [UITextField]
                    let enteredText = theTextField[0].text
                    print(enteredText!)
                    }}))
            present(controller, animated: true, completion: nil)
            
        case "UIAlertViewController with Multiple Buttons":
            let controller = UIAlertController(title: "Alert Controller", message: rowValue, preferredStyle: .alert)
            controller.addAction(UIAlertAction(title: "1",style: .default))
            controller.addAction(UIAlertAction(title: "2",style: .default))
            controller.addAction(UIAlertAction(title: "3",style: .default))
            controller.addAction(UIAlertAction(title: "4",style: .default))
            controller.addAction(UIAlertAction(title: "Cancel",style: .cancel))
            present(controller, animated: true, completion: nil)
            
        case "Standard UIActionSheet":
            let controller = UIAlertController(title: "Alert Sheet", message: rowValue, preferredStyle: .actionSheet)
            
            let destroy = UIAlertAction(title: "Delete", style: .destructive, handler: {(action) in
                print("Delete data")
            })
            controller.addAction(destroy)
            
            let ok = UIAlertAction(title: "OK", style: .default, handler: {(action) in
                print("Accept data")
            })
            controller.addAction(ok)
            
            let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: {(action) in
                print("Cancel action")
            })
            controller.addAction(cancel)
            present(controller, animated: true, completion: nil)
            
        default:
            let controller = UIAlertController(
                title: "Unidentified Alert Type",
                message: rowValue,
                preferredStyle: .alert)
            controller.addAction(UIAlertAction(title:"This should never happen!",style:.default))
            present(controller,animated:false,completion:nil)
        }
    }
    
    // "textCellIdentifier" is the name given to the prototype text cell in Identity Inspector
    // "myArray" is an array containing data to be loaded into the table

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

