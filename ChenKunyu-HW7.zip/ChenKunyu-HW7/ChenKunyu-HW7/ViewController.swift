//
//  ViewController.swift
//  ChenKunyu-HW7
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/4/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

var timers = [Timer]()

class ViewController: UIViewController, TimerDelegate, UITableViewDataSource, UITableViewDelegate, CountdownDelegate {
    
    func updateTimer(timeLeft: TimeInterval, row: Int) {
        timers[row].time = timeLeft
        tableView.reloadData()
    }
    
    @IBOutlet weak var tableView: UITableView!
    func addTimer(newEvent: String, newLocation: String, totalTime: TimeInterval) {
        let newTimer = Timer(eventName: newEvent, locationName: newLocation, totalTime: totalTime)
        timers.insert(newTimer, at: 0)
        tableView.reloadData()
    }
    
    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return timers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath:
        IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier:
            "TimerTableViewCell", for: indexPath as IndexPath) as! TimerTableViewCell
        
        let row = indexPath.row
        cell.timeLabel.text = "Remaining Time(s) " + String(Int(timers[row].time))
        cell.locationLabel.text = "Location " +  String(timers[row].location)
        cell.eventLabel.text = "Event " + String(timers[row].event)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "timerSegue", sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addSegue", let destination = segue.destination as? AddTimerViewController {
            destination.delegate = self
        }
        if segue.identifier == "timerSegue", let destination = segue.destination as? CountdownViewController, let row = tableView.indexPathForSelectedRow?.row {
            destination.delegate = self
            destination.curTimer = timers[row]
            destination.selectedRow = row
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
