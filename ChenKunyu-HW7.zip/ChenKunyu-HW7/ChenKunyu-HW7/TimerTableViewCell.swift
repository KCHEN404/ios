//
//  TimerTableViewCell.swift
//  ChenKunyu-HW7
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/4/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class TimerTableViewCell: UITableViewCell {

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var eventLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
