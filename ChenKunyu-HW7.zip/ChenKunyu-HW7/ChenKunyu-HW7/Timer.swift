//
//  Timer.swift
//  ChenKunyu-HW7
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/4/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import Foundation

class Timer {
    var event: String
    var location: String
    var time: TimeInterval
    
    init(eventName: String, locationName: String, totalTime: TimeInterval) {
        event = eventName
        location = locationName
        time = totalTime
    }
}
