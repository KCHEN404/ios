//
//  AddTimerViewController.swift
//  ChenKunyu-HW7
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/4/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

protocol TimerDelegate {
    func addTimer(newEvent: String, newLocation: String, totalTime: TimeInterval)
}

class AddTimerViewController: UIViewController {

    @IBOutlet weak var timeField: UITextField!
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var eventField: UITextField!
    
    var delegate : TimerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // This method is called when the user touches the Return key on the
    // keyboard. The 'textField' passed in is a pointer to the textField
    // widget the cursor was in at the time they touched the Return key on
    // the keyboard.
    //
    // From the Apple documentation: Asks the delegate if the text field
    // should process the pressing of the return button.
    //
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func savePressed(_ sender: Any) {
        guard let event = eventField.text,
            let location = locationField.text,
            let timeText = timeField.text,
            event.count > 0,
            location.count > 0,
            timeText.count > 0
        else {
            return
        }
        if delegate != nil {
            if let time = Int(timeText) {
                let totalTime = TimeInterval(time)
                delegate?.addTimer(newEvent: event, newLocation: location, totalTime: totalTime)
            }
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
