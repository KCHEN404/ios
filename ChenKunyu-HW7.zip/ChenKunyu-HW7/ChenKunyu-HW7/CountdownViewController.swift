//
//  CountdownViewController.swift
//  ChenKunyu-HW7
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/4/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit
import Foundation

protocol CountdownDelegate {
    func updateTimer(timeLeft: TimeInterval, row: Int)
}

class CountdownViewController: UIViewController {
    
    var curTimer : Timer?
    var exitStatus = false
    var selectedRow : Int?
    var delegate : CountdownDelegate?
    var countdown = 0
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var eventLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        if curTimer != nil {
            eventLabel.text = curTimer?.event
            locationLabel.text = curTimer?.location
            self.countdown = Int((curTimer?.time)!)
            timeLabel.text = String(self.countdown)
            DispatchQueue.global(qos: .userInteractive).async {
                while self.countdown > 0 && self.exitStatus == false {
                    sleep(1)
                    self.countdown -= 1
                    self.updateTimeLabel(time: self.countdown)
                }
            }
        }
        // Do any additional setup after loading the view.
    }

    func updateTimeLabel(time: Int) {
        DispatchQueue.main.async {
            self.timeLabel.text = String(time)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        exitStatus = true
        if delegate != nil {
            delegate?.updateTimer(timeLeft: TimeInterval(countdown) , row: selectedRow!)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
