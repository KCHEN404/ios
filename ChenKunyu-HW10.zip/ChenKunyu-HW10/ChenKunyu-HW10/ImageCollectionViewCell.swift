//
//  ImageCollectionViewCell.swift
//  ChenKunyu-HW10
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/14/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
