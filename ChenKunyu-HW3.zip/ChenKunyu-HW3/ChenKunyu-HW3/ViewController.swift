//
//  ViewController.swift
//  ChenKunyu-HW3
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 7/24/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class ViewController: UIViewController, NameDelegate, GenderDelegate {

    @IBOutlet weak var nameButton: UIButton!
    @IBOutlet weak var genderButton: UIButton!
    
    var storedName = ""
    
    func saveName(name: String) {
        storedName = name // save the current username
        nameButton.setTitle(name, for: UIControlState.normal)
    }
    
    func saveGender(gender: Int) {
        if gender == 0 {
            genderButton.setTitle("Female", for: UIControlState.normal)
        } else if gender == 1 {
            genderButton.setTitle("Male", for: UIControlState.normal)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "nameSegue" {
            let destination = segue.destination as? UsernameViewController
            destination?.delegate = self
            destination?.storedName = storedName // pass current username to Username View Controller
        }
        if segue.identifier == "genderSegue" {
            let destination = segue.destination as? GenderViewController
            destination?.delegate = self
        }
    }

}
