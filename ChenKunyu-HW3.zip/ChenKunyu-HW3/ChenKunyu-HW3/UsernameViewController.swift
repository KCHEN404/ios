//
//  UsernameViewController.swift
//  ChenKunyu-HW3
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 7/25/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

protocol NameDelegate {
    func saveName(name: String)
}

class UsernameViewController: UIViewController {

    @IBOutlet weak var nameField: UITextField!

    var delegate : NameDelegate? // an instance of NameDelegate
    var storedName = String() // current username
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameField.text = storedName // display current username in text field
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func savePressed(_ sender: Any) {
        let name = nameField.text!
        if delegate != nil {
            delegate?.saveName(name: name) // pass name to main VC using delegate
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
