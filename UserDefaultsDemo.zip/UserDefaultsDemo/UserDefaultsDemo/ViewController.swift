//
//  ViewController.swift
//  UserDefaultsDemo
//
//  Created by Chen, Kunyu on 8/8/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        demo()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func demo() {
        let idKey = "id"
        let totalKey = "total"
        let nameKey = "name"
        
        let userId = 900
        let total = 1275.55
        let name = "ut"
        
        let defaults = UserDefaults.standard
        
        defaults.set(userId, forKey: idKey)
        defaults.set(total, forKey: totalKey)
        defaults.set(name, forKey: nameKey)
        
        let reId = defaults.integer(forKey: idKey)
        let reTotal = defaults.double(forKey: totalKey)
        let reName = defaults.string(forKey: nameKey)
        
        print("   retrievedUserId:  \(reId)")
        print("   retrievedTotal:   \(reTotal)")
        print("   retrievedName:    \(reName!)")
        
    }


}

