//
//  ViewController.swift
//  ChenKunyu-HW5
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 7/27/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit
import CoreData

var noteData  = [NSManagedObject]()

class ViewController: UIViewController, NoteDelegate, UITableViewDataSource, UITableViewDelegate, UIPopoverPresentationControllerDelegate {
    func noteCreated(newNoteBody: String, newNoteDate: NSDate) {
        storeNote(date: newNoteDate, body: newNoteBody)
        noteData.removeAll()
        loadNotes()
        tableView.reloadData()
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    // To conform to UITableViewDataSource, you must implement
    // 3 methods:
    //    1.  numberOfSectionsInTableView
    //    2.  tableView:numberOfRowsInSection
    //    3.  tableView:cellForRowAtIndexPath
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection
        section: Int) -> Int {
        return noteData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath:
        IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier:
            "textNoteTableViewCell", for: indexPath as IndexPath) as! NoteTableViewCell
        
        let row = indexPath.row
        cell.createDate.text = getDate(note: noteData[row])
        cell.createTime.text = getTime(note: noteData[row])
        cell.bodyLabel.text = noteData[row].value(forKey: "body") as? String
        
        return cell
    }
    
    // "textCellIdentifier" is the name given to the prototype text cell in Identity Inspector
    // "myArray" is an array containing data to be loaded into the table
    
    func getDate(note: NSManagedObject) -> String {
        let myDateFormat = DateFormatter()
        myDateFormat.dateFormat = "MM/dd/yyyy"
        return myDateFormat.string(from: note.value(forKey: "date") as! Date)
    }
    
    func getTime(note: NSManagedObject) -> String {
        let myDateFormat = DateFormatter()
        myDateFormat.dateFormat = "HH:mm"
        return myDateFormat.string(from: note.value(forKey: "date") as! Date)
    }
 
//    func noteCreated(newNote: Note) {
//        noteData.insert(newNote, at: 0) // add new note to array
//        tableView.reloadData() // reload the tableview to show the new note
//    }

    override func viewDidLoad() {
        super.viewDidLoad()
        loadNotes()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showPopover", let destination = segue.destination as? PopoverViewController {
            destination.popoverPresentationController?.delegate = self // force popover on iPhone
            destination.delegate = self
        }

    }
    
    func loadNotes() {
        let fetchedResults = fetchNotes()
        if fetchedResults.count == 0 {
            storeNote(date: NSDate(), body: "Welcome to Quick Notes!")
            loadNotes()
        } else {
            for note in fetchedResults {
                noteData.insert(note, at: 0)
            }
        }
    }
    
    func storeNote(date: NSDate, body: String) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let note = NSEntityDescription.insertNewObject(forEntityName: "Note", into: context)
        
        note.setValue(date, forKey: "date")
        note.setValue(body, forKey: "body")
        
        do {
            try context.save()
        } catch {
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
    }
    
    func fetchNotes() -> [NSManagedObject] {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Note")
        var fetchedResults:[NSManagedObject]? = nil
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        } catch {
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }
    
    func clearCoreData() {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                
                for result:AnyObject in fetchedResults {
                    context.delete(result as! NSManagedObject)
                    print("\(result.value(forKey: "body")!) has been Deleted")
                }
            }
            try context.save()
            
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController, traitCollection: UITraitCollection) -> UIModalPresentationStyle {
        return UIModalPresentationStyle.none // force popover on iPhone
    }
    
}
