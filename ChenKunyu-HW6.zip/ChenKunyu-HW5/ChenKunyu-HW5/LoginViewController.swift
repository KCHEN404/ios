//
//  LoginViewController.swift
//  ChenKunyu-HW5
//
//  Created by Chen, Kunyu on 7/31/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var confirmLabel: UILabel!
    @IBOutlet weak var segCtrl: UISegmentedControl!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var confirmField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var nameField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        confirmField.isHidden = true
        confirmLabel.isHidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func segChanged(_ sender: Any) {
        if segCtrl.selectedSegmentIndex == 0 {
            confirmField.isHidden = true
            confirmLabel.isHidden = true
            button.titleLabel?.text = "Sign in"
        } else if segCtrl.selectedSegmentIndex == 1 {
            confirmField.isHidden = false
            confirmLabel.isHidden = false
            button.titleLabel?.text = "Sign up"
        }
            
    }
    
    @IBAction func buttonPressed(_ sender: Any) {
        if segCtrl.selectedSegmentIndex == 0 {
            // login using Firebase
        } else if segCtrl.selectedSegmentIndex == 1 {
            // sign up using Firebase
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
