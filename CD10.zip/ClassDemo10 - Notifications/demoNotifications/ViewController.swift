//
//  ViewController.swift
//  demoNotifications
//
//  Created by bulko on 3/6/18.
//  Copyright © 2018 bulko. All rights reserved.
//

import UIKit
import UserNotifications                            //   ADDED

// ADDED confrom to UUUserNotificationCenterDelegate protocol

class ViewController: UIViewController, UNUserNotificationCenterDelegate {
    
    var seconds:TimeInterval = 0.0
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var timerList: UISegmentedControl!
    @IBOutlet weak var secondsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //  ADDED  Set this view controller to be the delegate
        UNUserNotificationCenter.current().delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func moreSeconds(_ sender: Any) {
        seconds += 1.0
        secondsLabel.text = displaySeconds()
    }
    
    @IBAction func fewerSeconds(_ sender: Any) {
        seconds -= 1
        if seconds < 0 {
            seconds = 0.0
        }
        secondsLabel.text = displaySeconds()
    }
    
    @IBAction func setTimer(_ sender: Any) {
        
        // construct a string for display
        let index = timerList.selectedSegmentIndex
        let timerName = timerList.titleForSegment(at: index)!
        let status = displaySeconds() + " seconds " + timerName
        statusLabel.text = status + " set"
        
        // create an object that holds the data for our notification
        let notification = UNMutableNotificationContent()
        notification.title = timerName
        notification.subtitle = displaySeconds() + " second timer"
        notification.body = "Now complete"
        notification.badge = 17
        
        // set up the notification to trigger after a 5-second delay
        let notificationTrigger = UNTimeIntervalNotificationTrigger(timeInterval: seconds, repeats: false)
        
        // set up a request to tell iOS to submit the notification with that trigger
        let request = UNNotificationRequest(identifier: "notification1",
                                            content: notification,
                                            trigger: notificationTrigger)
        
        
        // submit the request to iOS
        UNUserNotificationCenter.current().add(request) { (error) in
            print("Request error: ",error as Any)
        }
        print("Submitted")

    }
    
    func displaySeconds() -> String {
        return String(format:"%02i",Int(seconds))
    }
    
    //  ADDED:  required method that presents the notification in the app.  While the app is currently
    //  open on the device screen, the notification will appear at the top.
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification:UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler ([.alert, .sound])
    }
    
    //  ADDED:  required method that indicates what actions, if any, you want to associate with your
    //  notification.
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        // I chose to do nothing here.
        
    }
    
}

