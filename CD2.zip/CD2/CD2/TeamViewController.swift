//
//  TeamViewController.swift
//  CD2
//
//  Created by Chen, Kunyu on 7/24/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit

class TeamViewController: UIViewController {

    @IBOutlet weak var teamLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    var teamName = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        teamLabel.text = "Team selected: \(teamName)"
        let teamIndex = teams.index(of: teamName)
        cityLabel.text = "City: \(cities[teamIndex!])"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
