//
//  ViewController.swift
//  ChenKunyu-HW9
//  EID: kc38294
//  Course: CS371L
//
//  Created by Chen, Kunyu on 8/12/18.
//  Copyright © 2018 Chen, Kunyu. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    
    var unitWidth : CGFloat?
    var unitHeight : CGFloat?
    var box : UILabel?
    var direction : String?
    var ended = 0 // whether the block hits the boundary
    var stateChangedCount = 0 // number of operations on the block (move left, move right, move up, move down, reset)

    override func viewDidLoad() {
        super.viewDidLoad()
        unitWidth = self.view.frame.size.width / 9
        unitHeight = self.view.frame.size.height / 19
        box = UILabel(frame: CGRect(x: 4 * unitWidth!, y: 8 * unitHeight!, width: unitWidth!, height: unitHeight!))
        box?.backgroundColor = UIColor.green
        self.view.addSubview(box!)
        
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(recognizeTapGesture(recognizer:)))
        self.view.addGestureRecognizer(tapRecognizer)
        
        let swipeRightRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeRightGesture(recognizer:)))
        swipeRightRecognizer.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRightRecognizer)
        
        let swipeLeftRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeLeftGesture(recognizer:)))
        swipeLeftRecognizer.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeftRecognizer)
        
        let swipeUpRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeUpGesture(recognizer:)))
        swipeUpRecognizer.direction = UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeUpRecognizer)
        
        let swipeDownRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(recognizeSwipeDownGesture(recognizer:)))
        swipeDownRecognizer.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipeDownRecognizer)
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func recognizeTapGesture(recognizer: UITapGestureRecognizer)
    {
        box?.frame.origin = CGPoint(x: 4 * unitWidth!, y: 8 * unitHeight!) // reset block to the center
        box?.backgroundColor = UIColor.green
        ended = 0
        stateChangedCount += 1
        DispatchQueue.global(qos: .userInteractive).async {
            self.direction = "down"
            self.moveBlock()
        }
    }
    
    func moveBlock() {
        let currentState = self.stateChangedCount
        while ended == 0 && currentState == self.stateChangedCount && checkPosition() { // break out of loop if next move will hit the boundary or receive new instruction
            DispatchQueue.main.sync {
                switch self.direction {
                case "down":
                    self.box?.frame.origin = CGPoint(x: (self.box?.frame.origin.x)!, y: (self.box?.frame.origin.y)! + self.unitHeight!)
                case "up":
                    self.box?.frame.origin = CGPoint(x: (self.box?.frame.origin.x)!, y: (self.box?.frame.origin.y)! - self.unitHeight!)
                case "left":
                    self.box?.frame.origin = CGPoint(x: (self.box?.frame.origin.x)! - self.unitWidth!, y: (self.box?.frame.origin.y)!)
                case "right":
                    self.box?.frame.origin = CGPoint(x: (self.box?.frame.origin.x)! + self.unitWidth!, y: (self.box?.frame.origin.y)!)
                default:
                    break
                }
            }
            usleep(300000)
        }
    }
    
    func checkPosition() -> Bool {
        // check whether next move will hit the boundary
        var result = true
        DispatchQueue.main.sync {
            switch self.direction {
            case "down":
                if (self.box?.frame.origin.y)! + 2 * self.unitHeight! > 19 * self.unitHeight! {
                    result = false
                    self.box?.backgroundColor = UIColor.red
                    self.ended = 1
                }
            case "up":
                if (self.box?.frame.origin.y)! - self.unitHeight! < 0 {
                    result = false
                    self.box?.backgroundColor = UIColor.red
                    self.ended = 1
                }
            case "left":
                if (self.box?.frame.origin.x)! - self.unitWidth! < 0 {
                    result = false
                    self.box?.backgroundColor = UIColor.red
                    self.ended = 1
                }
            case "right":
                if (self.box?.frame.origin.x)! + 2 * self.unitWidth! > 9 * self.unitWidth! {
                    result = false
                    self.box?.backgroundColor = UIColor.red
                    self.ended = 1
                }
            default:
                break
            }
        }
        return result
    }
    
    @IBAction func recognizeSwipeRightGesture(recognizer: UISwipeGestureRecognizer)
    {
        if recognizer.state == .ended {
            stateChangedCount += 1
            DispatchQueue.global(qos: .userInteractive).async {
                self.direction = "right"
                self.moveBlock()
            }
        }
    }
    
    @IBAction func recognizeSwipeLeftGesture(recognizer: UISwipeGestureRecognizer)
    {
        if recognizer.state == .ended {
            stateChangedCount += 1
            DispatchQueue.global(qos: .userInteractive).async {
                self.direction = "left"
                self.moveBlock()
            }
        }
    }
    
    @IBAction func recognizeSwipeUpGesture(recognizer: UISwipeGestureRecognizer)
    {
        if recognizer.state == .ended {
            stateChangedCount += 1
            DispatchQueue.global(qos: .userInteractive).async {
                self.direction = "up"
                self.moveBlock()
            }
        }
    }
    
    @IBAction func recognizeSwipeDownGesture(recognizer: UISwipeGestureRecognizer)
    {
        if recognizer.state == .ended {
            stateChangedCount += 1
            DispatchQueue.global(qos: .userInteractive).async {
                self.direction = "down"
                self.moveBlock()
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
